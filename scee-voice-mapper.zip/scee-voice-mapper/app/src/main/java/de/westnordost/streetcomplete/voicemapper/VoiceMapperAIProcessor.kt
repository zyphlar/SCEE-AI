package de.westnordost.streetcomplete.voicemapper

import android.util.Log
import de.westnordost.streetcomplete.data.osm.mapdata.Element
import de.westnordost.streetcomplete.data.osm.mapdata.ElementType
import de.westnordost.streetcomplete.data.osm.mapdata.LatLon
import de.westnordost.streetcomplete.data.osm.mapdata.Node
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * AI Processor for Voice Mapper
 * 
 * Uses Claude API to understand natural language voice commands and convert them
 * into structured OSM edits. The AI has knowledge of:
 * - OSM tagging conventions
 * - Common POI types and their proper tags
 * - Brand names and their Wikidata identifiers
 * - Address formatting (addr:housenumber, addr:street, etc.)
 * - Relative positioning (left/right of road, distance estimates)
 */
class VoiceMapperAIProcessor(
    private val apiKey: String,
    private val apiEndpoint: String = "https://api.anthropic.com/v1/messages"
) {
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    private val json = Json { 
        ignoreUnknownKeys = true
        isLenient = true
    }
    
    /**
     * Process a voice command and return structured edits
     */
    suspend fun processVoiceCommand(context: VoiceMapperContext): VoiceMapperAIResponse {
        return withContext(Dispatchers.IO) {
            try {
                // First, try local parsing for common patterns
                val localResult = tryLocalParsing(context)
                if (localResult != null && localResult.success) {
                    return@withContext localResult
                }
                
                // Fall back to AI for complex commands
                callClaudeAPI(context)
            } catch (e: Exception) {
                Log.e(TAG, "Error processing voice command", e)
                VoiceMapperAIResponse(
                    success = false,
                    errorMessage = "Failed to process command: ${e.message}"
                )
            }
        }
    }
    
    /**
     * Try to parse common patterns locally without API call
     * This handles simple cases like "McDonald's on the left"
     */
    private fun tryLocalParsing(context: VoiceMapperContext): VoiceMapperAIResponse? {
        val transcription = context.transcription.lowercase()
        
        // Parse side indicators
        val side = when {
            transcription.contains("on the left") || transcription.contains("to the left") || 
            transcription.contains("left side") || transcription.contains("on my left") -> RelativeSide.LEFT
            transcription.contains("on the right") || transcription.contains("to the right") ||
            transcription.contains("right side") || transcription.contains("on my right") -> RelativeSide.RIGHT
            transcription.contains("ahead") || transcription.contains("in front") ||
            transcription.contains("straight ahead") -> RelativeSide.CENTER
            else -> null
        }
        
        // Try to find known features
        val edits = mutableListOf<VoiceMapperEdit>()
        
        // Split by common separators (comma, "and", etc.)
        val parts = transcription
            .replace(" and ", ",")
            .replace(", and ", ",")
            .split(",")
            .map { it.trim() }
        
        // Extract addresses if present
        val addressPattern = Regex("""(?:address(?:es)?|numbers?)\s*(?:are|is)?\s*([\d,\s]+)""")
        val addressMatch = addressPattern.find(transcription)
        val addresses = addressMatch?.groupValues?.get(1)
            ?.split(Regex("[,\\s]+"))
            ?.filter { it.isNotBlank() }
            ?.mapNotNull { it.trim().toIntOrNull() }
            ?: emptyList()
        
        // Also try pattern like "123, 125, 127" or "with addresses 123, 125, 127"
        val numberPattern = Regex("""(\d{1,5})(?:\s*,\s*(\d{1,5}))*""")
        val numbers = if (addresses.isEmpty()) {
            numberPattern.findAll(transcription)
                .flatMap { match -> 
                    match.value.split(",").mapNotNull { it.trim().toIntOrNull() }
                }
                .toList()
        } else addresses
        
        var addressIndex = 0
        
        for (part in parts) {
            // Clean up the part
            val cleanPart = part
                .replace(Regex("on the (left|right)"), "")
                .replace(Regex("to the (left|right)"), "")
                .replace(Regex("(left|right) side"), "")
                .replace(Regex("on my (left|right)"), "")
                .replace(Regex("address(?:es)?\\s*(?:are|is)?\\s*[\\d,\\s]+"), "")
                .replace(Regex("with address(?:es)?.*"), "")
                .replace(Regex("numbers?\\s*(?:are|is)?\\s*[\\d,\\s]+"), "")
                .replace(Regex("\\d{1,5}"), "")
                .trim()
            
            if (cleanPart.isBlank()) continue
            
            // Look up feature
            val tags = OSMFeatures.lookupFeature(cleanPart)
            if (tags != null) {
                val mutableTags = tags.toMutableMap()
                
                // Add name if it's a brand (name is usually the brand name for branded POIs)
                val brand = tags["brand"]
                if (brand != null && !mutableTags.containsKey("name")) {
                    mutableTags["name"] = brand
                }
                
                // Add address if available
                if (addressIndex < numbers.size) {
                    mutableTags["addr:housenumber"] = numbers[addressIndex].toString()
                    addressIndex++
                }
                
                // Add street name from current road
                context.currentRoadName?.let { 
                    mutableTags["addr:street"] = it
                }
                
                edits.add(VoiceMapperEdit(
                    type = EditType.CREATE_NODE,
                    description = "Add ${tags["brand"] ?: tags["amenity"] ?: tags["shop"] ?: "POI"}",
                    tags = mutableTags,
                    relativeSide = side ?: RelativeSide.RIGHT, // Default to right side
                    distanceAhead = 0.0,
                    distanceSide = 15.0, // Default 15m from road center
                    confidence = if (side != null) 0.85f else 0.7f
                ))
            }
        }
        
        if (edits.isNotEmpty()) {
            return VoiceMapperAIResponse(
                success = true,
                edits = edits,
                audioFeedback = "Found ${edits.size} ${if (edits.size == 1) "location" else "locations"} to add"
            )
        }
        
        return null
    }
    
    /**
     * Call Claude API for complex command parsing
     */
    private suspend fun callClaudeAPI(context: VoiceMapperContext): VoiceMapperAIResponse {
        val systemPrompt = buildSystemPrompt()
        val userMessage = buildUserMessage(context)
        
        val requestBody = buildJsonObject {
            put("model", "claude-sonnet-4-20250514")
            put("max_tokens", 2000)
            put("system", systemPrompt)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "user")
                    put("content", userMessage)
                }
            }
        }
        
        val request = Request.Builder()
            .url(apiEndpoint)
            .addHeader("Content-Type", "application/json")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
        
        val response = client.newCall(request).execute()
        
        if (!response.isSuccessful) {
            return VoiceMapperAIResponse(
                success = false,
                errorMessage = "API error: ${response.code} ${response.message}"
            )
        }
        
        val responseBody = response.body?.string() ?: return VoiceMapperAIResponse(
            success = false,
            errorMessage = "Empty response from API"
        )
        
        return parseAIResponse(responseBody, context)
    }
    
    private fun buildSystemPrompt(): String = """
You are an expert OpenStreetMap mapper assistant integrated into the SCEE app. Your job is to interpret voice commands from a driver/cyclist/walker who is mapping POIs while moving.

You understand:
1. OSM tagging schemes - you know the correct tags for all POI types
2. Brand names and their Wikidata identifiers  
3. Relative positioning - "on the left", "on the right", "ahead", "behind"
4. Distance estimates - "about 20 meters", "just passed it"
5. Address formatting - addr:housenumber, addr:street, addr:city, etc.
6. Opening hours format (if mentioned)

When given a voice command, you will output a JSON response with the following structure:
```json
{
  "success": true,
  "edits": [
    {
      "type": "CREATE_NODE|MODIFY_NODE|DELETE_NODE|MODIFY_TAGS",
      "description": "Human readable description of the edit",
      "tags": {
        "amenity": "fast_food",
        "brand": "McDonald's",
        "brand:wikidata": "Q38076",
        "name": "McDonald's",
        "cuisine": "burger",
        "addr:housenumber": "123",
        "addr:street": "Main Street"
      },
      "tagsToRemove": [],
      "side": "LEFT|RIGHT|CENTER",
      "distanceAhead": 0,
      "distanceSide": 15,
      "confidence": 0.9,
      "explanation": "Why I interpreted it this way"
    }
  ],
  "clarificationNeeded": null,
  "audioFeedback": "Adding McDonald's on the left"
}
```

Key rules:
1. Always include brand:wikidata for known brands
2. For fast food, always include cuisine tag
3. If multiple POIs are mentioned, create multiple edits
4. If addresses are mentioned with POIs, match them in order
5. Use the current road name for addr:street if available
6. Set confidence lower (0.5-0.7) if you're unsure about interpretation
7. If the command is unclear, set clarificationNeeded to a question
8. For deletions, include element_id if available from nearby elements

Common tagging patterns:
- Fast food: amenity=fast_food, brand=X, name=X, cuisine=Y
- Gas station: amenity=fuel, brand=X, name=X  
- Restaurant: amenity=restaurant, name=X, cuisine=Y
- Bank: amenity=bank, brand=X, name=X
- ATM: amenity=atm
- Shop: shop=X, brand=Y (if applicable), name=Z
- Bench: amenity=bench
- Parking: amenity=parking

Always output valid JSON only, no markdown formatting.
""".trimIndent()
    
    private fun buildUserMessage(context: VoiceMapperContext): String {
        val nearbyInfo = buildString {
            append("Nearby elements:\n")
            context.nearbyElements.take(20).forEach { element ->
                val name = element.tags["name"] ?: element.tags["brand"] ?: ""
                val type = element.tags["amenity"] ?: element.tags["shop"] ?: element.tags["leisure"] ?: ""
                if (name.isNotBlank() || type.isNotBlank()) {
                    append("- ${element.type}/${element.id}: $type ${if (name.isNotBlank()) "\"$name\"" else ""}\n")
                }
            }
        }
        
        return """
Voice command: "${context.transcription}"

Current location:
- Latitude: ${context.latitude}
- Longitude: ${context.longitude}  
- Bearing: ${context.bearing}° (0=North, 90=East, 180=South, 270=West)
- Speed: ${context.speed} m/s
- Current road: ${context.currentRoadName ?: "Unknown"} ${context.currentRoadRef?.let { "($it)" } ?: ""}

$nearbyInfo

Parse this voice command and return the JSON response.
""".trimIndent()
    }
    
    private fun parseAIResponse(responseBody: String, context: VoiceMapperContext): VoiceMapperAIResponse {
        try {
            val jsonResponse = json.parseToJsonElement(responseBody).jsonObject
            val content = jsonResponse["content"]?.jsonArray?.firstOrNull()
                ?.jsonObject?.get("text")?.jsonPrimitive?.content
                ?: return VoiceMapperAIResponse(success = false, errorMessage = "No content in response")
            
            // Clean up any markdown code blocks
            val cleanJson = content
                .replace(Regex("```json\\s*"), "")
                .replace(Regex("```\\s*"), "")
                .trim()
            
            val parsed = json.parseToJsonElement(cleanJson).jsonObject
            
            val success = parsed["success"]?.jsonPrimitive?.boolean ?: false
            val clarificationNeeded = parsed["clarificationNeeded"]?.jsonPrimitive?.contentOrNull
            val audioFeedback = parsed["audioFeedback"]?.jsonPrimitive?.contentOrNull
            
            if (!success) {
                return VoiceMapperAIResponse(
                    success = false,
                    errorMessage = parsed["error"]?.jsonPrimitive?.contentOrNull ?: "AI could not process command",
                    clarificationNeeded = clarificationNeeded
                )
            }
            
            val editsArray = parsed["edits"]?.jsonArray ?: return VoiceMapperAIResponse(
                success = false,
                errorMessage = "No edits in response"
            )
            
            val edits = editsArray.mapNotNull { editJson ->
                try {
                    val editObj = editJson.jsonObject
                    
                    val typeStr = editObj["type"]?.jsonPrimitive?.content ?: "CREATE_NODE"
                    val type = EditType.valueOf(typeStr)
                    
                    val description = editObj["description"]?.jsonPrimitive?.content ?: "Edit"
                    
                    val tags = editObj["tags"]?.jsonObject?.let { tagsObj ->
                        tagsObj.entries.associate { (key, value) ->
                            key to value.jsonPrimitive.content
                        }
                    } ?: emptyMap()
                    
                    val tagsToRemove = editObj["tagsToRemove"]?.jsonArray?.map { 
                        it.jsonPrimitive.content 
                    }?.toSet() ?: emptySet()
                    
                    val sideStr = editObj["side"]?.jsonPrimitive?.contentOrNull ?: "RIGHT"
                    val side = try {
                        RelativeSide.valueOf(sideStr)
                    } catch (e: Exception) {
                        RelativeSide.RIGHT
                    }
                    
                    val distanceAhead = editObj["distanceAhead"]?.jsonPrimitive?.doubleOrNull ?: 0.0
                    val distanceSide = editObj["distanceSide"]?.jsonPrimitive?.doubleOrNull ?: 15.0
                    val confidence = editObj["confidence"]?.jsonPrimitive?.floatOrNull ?: 0.8f
                    val explanation = editObj["explanation"]?.jsonPrimitive?.contentOrNull
                    
                    VoiceMapperEdit(
                        type = type,
                        description = description,
                        tags = tags,
                        tagsToRemove = tagsToRemove,
                        relativeSide = side,
                        distanceAhead = distanceAhead,
                        distanceSide = distanceSide,
                        confidence = confidence,
                        aiExplanation = explanation
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing edit", e)
                    null
                }
            }
            
            return VoiceMapperAIResponse(
                success = true,
                edits = edits,
                clarificationNeeded = clarificationNeeded,
                audioFeedback = audioFeedback
            )
            
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing AI response", e)
            return VoiceMapperAIResponse(
                success = false,
                errorMessage = "Failed to parse AI response: ${e.message}"
            )
        }
    }
    
    /**
     * Offline fallback using fuzzy matching
     * Used when API is not available
     */
    fun processOffline(context: VoiceMapperContext): VoiceMapperAIResponse {
        val result = tryLocalParsing(context)
        return result ?: VoiceMapperAIResponse(
            success = false,
            errorMessage = "Could not understand command. Try: '[POI name] on the [left/right]'"
        )
    }
    
    companion object {
        private const val TAG = "VoiceMapperAI"
    }
}

// Extension to safely get content or null
private val JsonPrimitive.contentOrNull: String?
    get() = if (isString) content else null

private val JsonPrimitive.doubleOrNull: Double?
    get() = try { double } catch (e: Exception) { null }

private val JsonPrimitive.floatOrNull: Float?
    get() = try { float } catch (e: Exception) { null }
