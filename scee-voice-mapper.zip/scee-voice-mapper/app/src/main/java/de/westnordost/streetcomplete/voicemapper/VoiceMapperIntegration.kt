package de.westnordost.streetcomplete.voicemapper

import android.location.Location
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import de.westnordost.streetcomplete.R
import org.koin.android.ext.android.inject

/**
 * Example integration of VoiceMapper into SCEE MainActivity
 * 
 * This file shows how to integrate the voice mapper feature.
 * Copy relevant sections to your actual MainActivity.
 */

// Add this to your existing MainActivity class
class VoiceMapperIntegrationExample : AppCompatActivity() {
    
    private val voiceMapperService: VoiceMapperService by inject()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // ... your existing onCreate code ...
        
        // Add voice mapper button to your main UI
        setupVoiceMapperButton()
    }
    
    private fun setupVoiceMapperButton() {
        // Option 1: Add as a FAB
        // In your layout XML, add:
        // <com.google.android.material.floatingactionbutton.FloatingActionButton
        //     android:id="@+id/voiceMapperFab"
        //     android:layout_width="wrap_content"
        //     android:layout_height="wrap_content"
        //     android:src="@drawable/ic_mic"
        //     ... />
        
        findViewById<View>(R.id.voiceMapperFab)?.setOnClickListener {
            showVoiceMapper()
        }
        
        // Option 2: Add to overflow menu
        // Add to your menu XML:
        // <item
        //     android:id="@+id/action_voice_mapper"
        //     android:title="Voice Mapper"
        //     android:icon="@drawable/ic_mic" />
    }
    
    private fun showVoiceMapper() {
        // Show voice mapper as a bottom sheet or fragment
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, VoiceMapperFragment.newInstance(), "voice_mapper")
            .addToBackStack("voice_mapper")
            .commit()
    }
    
    /**
     * Forward location updates to voice mapper
     * Call this from your existing location listener
     */
    fun onLocationUpdated(location: Location) {
        voiceMapperService.updateLocation(location, location.bearing)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        voiceMapperService.destroy()
    }
}

/**
 * Alternative: Add voice mapper as an overlay on the map
 * This shows how to add a minimal voice control overlay
 */
class VoiceMapperOverlayFragment : Fragment(R.layout.fragment_voice_mapper) {
    
    private val voiceMapperService: VoiceMapperService by inject()
    
    // This fragment can be added as an overlay on top of the map
    // It shows just the microphone button and pending edits
    
    companion object {
        fun newInstance() = VoiceMapperOverlayFragment()
    }
}

/**
 * Add to your MainModule.kt or equivalent Koin module
 */
/*
val mainModule = module {
    // ... existing module content ...
    
    // Include voice mapper module
    includes(voiceMapperModule)
}
*/

/**
 * Add to your build.gradle.kts
 */
/*
dependencies {
    // Voice mapper dependencies
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0")
    
    // TTS and speech recognition are part of Android SDK
}
*/

/**
 * Add to your strings.xml
 */
/*
<resources>
    <string name="voice_mapper_title">Voice Mapper</string>
    <string name="voice_mapper_hint">Tap to speak • Long press for continuous</string>
    <string name="voice_mapper_listening">Listening...</string>
    <string name="voice_mapper_processing">Processing...</string>
    <string name="voice_mapper_confirm_all">Confirm All</string>
    <string name="voice_mapper_cancel">Cancel</string>
    <string name="voice_mapper_pending">%d pending</string>
    <string name="voice_mapper_continuous_enabled">Continuous mode enabled</string>
    <string name="voice_mapper_continuous_disabled">Continuous mode disabled</string>
    <string name="voice_mapper_items_added">%d items added to map</string>
</resources>
*/
