package de.westnordost.streetcomplete.voicemapper

import de.westnordost.streetcomplete.data.osm.edits.ElementEditAction
import de.westnordost.streetcomplete.data.osm.edits.ElementIdProvider
import de.westnordost.streetcomplete.data.osm.edits.IsActionRevertable
import de.westnordost.streetcomplete.data.osm.edits.NewElementsCount
import de.westnordost.streetcomplete.data.osm.mapdata.*
import de.westnordost.streetcomplete.util.ktx.nowAsEpochMilliseconds
import kotlinx.serialization.Serializable

/**
 * Action to create a new node at a specific position with given tags
 */
@Serializable
data class CreateNodeAction(
    val position: LatLon,
    val tags: Map<String, String>
) : ElementEditAction, IsActionRevertable {
    
    override val newElementsCount: NewElementsCount
        get() = NewElementsCount(1, 0, 0)
    
    override fun createUpdates(
        originalElement: Element?,
        element: Element?,
        mapDataRepository: MapDataRepository,
        idProvider: ElementIdProvider
    ): MapDataChanges {
        val nodeId = idProvider.nextNodeId()
        
        val node = Node(
            id = nodeId,
            position = position,
            tags = tags,
            version = 1
        )
        
        return MapDataChanges(creations = listOf(node))
    }
    
    override fun createReverted(element: Element?): ElementEditAction {
        // Revert by deleting the created node
        val nodeId = (element as? Node)?.id ?: -1
        return DeleteNodeAction(nodeId)
    }
}

/**
 * Action to update tags on an existing element
 */
@Serializable
data class UpdateTagsAction(
    val tagsToAdd: Map<String, String>,
    val tagsToRemove: Set<String> = emptySet()
) : ElementEditAction, IsActionRevertable {
    
    override val newElementsCount: NewElementsCount
        get() = NewElementsCount(0, 0, 0)
    
    override fun createUpdates(
        originalElement: Element?,
        element: Element?,
        mapDataRepository: MapDataRepository,
        idProvider: ElementIdProvider
    ): MapDataChanges {
        val el = element ?: return MapDataChanges()
        
        val newTags = el.tags.toMutableMap()
        newTags.putAll(tagsToAdd)
        tagsToRemove.forEach { newTags.remove(it) }
        
        val updatedElement = when (el) {
            is Node -> el.copy(tags = newTags)
            is Way -> el.copy(tags = newTags)
            is Relation -> el.copy(tags = newTags)
        }
        
        return MapDataChanges(modifications = listOf(updatedElement))
    }
    
    override fun createReverted(element: Element?): ElementEditAction {
        val el = element ?: return UpdateTagsAction(emptyMap(), emptySet())
        
        // To revert: remove the tags we added, restore the tags we removed
        val revertTagsToAdd = el.tags.filterKeys { it in tagsToRemove }
        val revertTagsToRemove = tagsToAdd.keys
        
        return UpdateTagsAction(revertTagsToAdd, revertTagsToRemove)
    }
}

/**
 * Action to delete a node
 */
@Serializable  
data class DeleteNodeAction(
    val nodeId: Long
) : ElementEditAction, IsActionRevertable {
    
    private var deletedNode: Node? = null
    
    override val newElementsCount: NewElementsCount
        get() = NewElementsCount(0, 0, 0)
    
    override fun createUpdates(
        originalElement: Element?,
        element: Element?,
        mapDataRepository: MapDataRepository,
        idProvider: ElementIdProvider
    ): MapDataChanges {
        val node = element as? Node ?: mapDataRepository.getNode(nodeId) ?: return MapDataChanges()
        
        // Check if node is part of any ways
        val waysContainingNode = mapDataRepository.getWaysForNode(nodeId)
        if (waysContainingNode.isNotEmpty()) {
            // Cannot delete nodes that are part of ways without handling the ways
            // In this case, we just remove all tags instead (making it a bare node)
            val updatedNode = node.copy(tags = emptyMap())
            return MapDataChanges(modifications = listOf(updatedNode))
        }
        
        // Store for potential revert
        deletedNode = node
        
        return MapDataChanges(deletions = listOf(node))
    }
    
    override fun createReverted(element: Element?): ElementEditAction {
        val node = deletedNode ?: (element as? Node) ?: return CreateNodeAction(
            LatLon(0.0, 0.0),
            emptyMap()
        )
        
        return CreateNodeAction(node.position, node.tags)
    }
}

/**
 * Action to move a node to a new position
 */
@Serializable
data class MoveNodeAction(
    val newPosition: LatLon
) : ElementEditAction, IsActionRevertable {
    
    private var oldPosition: LatLon? = null
    
    override val newElementsCount: NewElementsCount
        get() = NewElementsCount(0, 0, 0)
    
    override fun createUpdates(
        originalElement: Element?,
        element: Element?,
        mapDataRepository: MapDataRepository,
        idProvider: ElementIdProvider
    ): MapDataChanges {
        val node = element as? Node ?: return MapDataChanges()
        
        oldPosition = node.position
        
        val updatedNode = node.copy(position = newPosition)
        return MapDataChanges(modifications = listOf(updatedNode))
    }
    
    override fun createReverted(element: Element?): ElementEditAction {
        val position = oldPosition ?: (element as? Node)?.position ?: LatLon(0.0, 0.0)
        return MoveNodeAction(position)
    }
}

/**
 * Action to insert a node into an existing way
 */
@Serializable
data class InsertNodeIntoWayAction(
    val wayId: Long,
    val position: LatLon,
    val tags: Map<String, String>,
    val insertAfterNodeId: Long? = null
) : ElementEditAction {
    
    override val newElementsCount: NewElementsCount
        get() = NewElementsCount(1, 0, 0)
    
    override fun createUpdates(
        originalElement: Element?,
        element: Element?,
        mapDataRepository: MapDataRepository,
        idProvider: ElementIdProvider
    ): MapDataChanges {
        val way = mapDataRepository.getWay(wayId) ?: return MapDataChanges()
        
        // Create new node
        val nodeId = idProvider.nextNodeId()
        val newNode = Node(
            id = nodeId,
            position = position,
            tags = tags,
            version = 1
        )
        
        // Find insertion point
        val insertIndex = if (insertAfterNodeId != null) {
            val afterIndex = way.nodeIds.indexOf(insertAfterNodeId)
            if (afterIndex >= 0) afterIndex + 1 else way.nodeIds.size
        } else {
            // Find closest segment and insert there
            findBestInsertionIndex(way, position, mapDataRepository)
        }
        
        // Create updated way with new node
        val newNodeIds = way.nodeIds.toMutableList()
        newNodeIds.add(insertIndex, nodeId)
        
        val updatedWay = way.copy(nodeIds = newNodeIds)
        
        return MapDataChanges(
            creations = listOf(newNode),
            modifications = listOf(updatedWay)
        )
    }
    
    private fun findBestInsertionIndex(
        way: Way,
        position: LatLon,
        mapDataRepository: MapDataRepository
    ): Int {
        var bestIndex = way.nodeIds.size
        var bestDistance = Double.MAX_VALUE
        
        for (i in 0 until way.nodeIds.size - 1) {
            val node1 = mapDataRepository.getNode(way.nodeIds[i]) ?: continue
            val node2 = mapDataRepository.getNode(way.nodeIds[i + 1]) ?: continue
            
            val distance = distanceToSegment(position, node1.position, node2.position)
            if (distance < bestDistance) {
                bestDistance = distance
                bestIndex = i + 1
            }
        }
        
        return bestIndex
    }
    
    private fun distanceToSegment(point: LatLon, segStart: LatLon, segEnd: LatLon): Double {
        val dx = segEnd.longitude - segStart.longitude
        val dy = segEnd.latitude - segStart.latitude
        
        if (dx == 0.0 && dy == 0.0) {
            return haversineDistance(point, segStart)
        }
        
        val t = maxOf(0.0, minOf(1.0,
            ((point.longitude - segStart.longitude) * dx + (point.latitude - segStart.latitude) * dy) /
            (dx * dx + dy * dy)
        ))
        
        val projLon = segStart.longitude + t * dx
        val projLat = segStart.latitude + t * dy
        
        return haversineDistance(point, LatLon(projLat, projLon))
    }
    
    private fun haversineDistance(p1: LatLon, p2: LatLon): Double {
        val earthRadius = 6371000.0
        val dLat = Math.toRadians(p2.latitude - p1.latitude)
        val dLon = Math.toRadians(p2.longitude - p1.longitude)
        val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
                kotlin.math.cos(Math.toRadians(p1.latitude)) * 
                kotlin.math.cos(Math.toRadians(p2.latitude)) *
                kotlin.math.sin(dLon / 2) * kotlin.math.sin(dLon / 2)
        val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
        return earthRadius * c
    }
}
