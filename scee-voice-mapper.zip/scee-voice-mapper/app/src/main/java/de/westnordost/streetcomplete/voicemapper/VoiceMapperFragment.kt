package de.westnordost.streetcomplete.voicemapper

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import de.westnordost.streetcomplete.R
import de.westnordost.streetcomplete.databinding.FragmentVoiceMapperBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.Locale

/**
 * Fragment for the Voice Mapper feature
 * 
 * Provides:
 * - Voice recording button with visual feedback
 * - Live transcription display  
 * - Pending edits list with confirm/reject
 * - Audio feedback via TTS
 * - Quick correction interface
 */
class VoiceMapperFragment : Fragment() {
    
    private var _binding: FragmentVoiceMapperBinding? = null
    private val binding get() = _binding!!
    
    private val viewModel: VoiceMapperViewModel by viewModel()
    private val voiceMapperService: VoiceMapperService by inject()
    
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    
    private val pendingEditsAdapter = PendingEditsAdapter(
        onConfirm = { edit -> viewModel.confirmEdit(edit) },
        onReject = { edit -> viewModel.rejectEdit(edit) },
        onEdit = { edit -> showEditDialog(edit) }
    )
    
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        } else {
            Toast.makeText(requireContext(), 
                "Microphone permission is required for voice mapping", 
                Toast.LENGTH_LONG
            ).show()
        }
    }
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentVoiceMapperBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupTTS()
        setupUI()
        observeState()
    }
    
    private fun setupTTS() {
        tts = TextToSpeech(requireContext()) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                ttsReady = true
            }
        }
    }
    
    private fun setupUI() {
        // Voice button
        binding.voiceButton.setOnClickListener {
            toggleListening()
        }
        
        // Long press for continuous mode
        binding.voiceButton.setOnLongClickListener {
            viewModel.toggleContinuousMode()
            true
        }
        
        // Confirm all button
        binding.confirmAllButton.setOnClickListener {
            viewModel.confirmAllEdits()
        }
        
        // Cancel all button
        binding.cancelAllButton.setOnClickListener {
            viewModel.cancelAllEdits()
        }
        
        // Settings button
        binding.settingsButton.setOnClickListener {
            showSettingsDialog()
        }
        
        // Help button
        binding.helpButton.setOnClickListener {
            showHelpDialog()
        }
        
        // Pending edits list
        binding.pendingEditsList.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = pendingEditsAdapter
        }
    }
    
    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                // Observe listening state
                launch {
                    viewModel.isListening.collectLatest { isListening ->
                        updateVoiceButton(isListening)
                    }
                }
                
                // Observe continuous mode
                launch {
                    viewModel.isContinuousMode.collectLatest { isContinuous ->
                        binding.continuousModeIndicator.visibility = 
                            if (isContinuous) View.VISIBLE else View.GONE
                    }
                }
                
                // Observe transcription
                launch {
                    viewModel.currentTranscription.collectLatest { text ->
                        binding.transcriptionText.text = text ?: ""
                        binding.transcriptionCard.visibility = 
                            if (text.isNullOrBlank()) View.GONE else View.VISIBLE
                    }
                }
                
                // Observe pending edits
                launch {
                    viewModel.pendingEdits.collectLatest { edits ->
                        pendingEditsAdapter.submitList(edits)
                        binding.pendingEditsContainer.visibility = 
                            if (edits.isEmpty()) View.GONE else View.VISIBLE
                        binding.pendingEditsCount.text = "${edits.size} pending"
                    }
                }
                
                // Observe events
                launch {
                    viewModel.events.collectLatest { event ->
                        handleEvent(event)
                    }
                }
                
                // Observe processing state
                launch {
                    viewModel.isProcessing.collectLatest { isProcessing ->
                        binding.processingIndicator.visibility = 
                            if (isProcessing) View.VISIBLE else View.GONE
                    }
                }
            }
        }
    }
    
    private fun toggleListening() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        
        viewModel.toggleListening()
    }
    
    private fun updateVoiceButton(isListening: Boolean) {
        binding.voiceButton.apply {
            if (isListening) {
                setImageResource(R.drawable.ic_mic_active)
                setColorFilter(ContextCompat.getColor(requireContext(), R.color.accent))
                // Pulse animation
                animate()
                    .scaleX(1.2f)
                    .scaleY(1.2f)
                    .setDuration(500)
                    .withEndAction {
                        animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setDuration(500)
                            .start()
                    }
                    .start()
            } else {
                setImageResource(R.drawable.ic_mic)
                clearColorFilter()
                animate().cancel()
                scaleX = 1.0f
                scaleY = 1.0f
            }
        }
    }
    
    private fun handleEvent(event: VoiceMapperEvent) {
        when (event) {
            is VoiceMapperEvent.ReadyForSpeech -> {
                binding.statusText.text = "Listening..."
                binding.statusText.setTextColor(Color.GREEN)
            }
            
            is VoiceMapperEvent.SpeechStarted -> {
                binding.statusText.text = "Speaking..."
            }
            
            is VoiceMapperEvent.SpeechEnded -> {
                binding.statusText.text = "Processing..."
            }
            
            is VoiceMapperEvent.Error -> {
                binding.statusText.text = event.message
                binding.statusText.setTextColor(Color.RED)
                Toast.makeText(requireContext(), event.message, Toast.LENGTH_SHORT).show()
            }
            
            is VoiceMapperEvent.PartialTranscription -> {
                binding.transcriptionText.text = event.text
                binding.transcriptionCard.visibility = View.VISIBLE
            }
            
            is VoiceMapperEvent.ProcessingStarted -> {
                binding.transcriptionText.text = event.transcription
            }
            
            is VoiceMapperEvent.EditsPending -> {
                speakFeedback("${event.edits.size} edits pending confirmation")
            }
            
            is VoiceMapperEvent.EditsApplied -> {
                binding.statusText.text = "Added ${event.count} items"
                binding.statusText.setTextColor(Color.GREEN)
                speakFeedback("${event.count} items added to map")
            }
            
            is VoiceMapperEvent.EditsCancelled -> {
                binding.statusText.text = "Edits cancelled"
            }
            
            is VoiceMapperEvent.NodeCreated -> {
                // Individual edit feedback handled elsewhere
            }
            
            is VoiceMapperEvent.NodeModified -> {
                // Individual edit feedback handled elsewhere
            }
            
            is VoiceMapperEvent.NodeDeleted -> {
                // Individual edit feedback handled elsewhere
            }
            
            is VoiceMapperEvent.TagsModified -> {
                // Individual edit feedback handled elsewhere
            }
            
            is VoiceMapperEvent.ClarificationNeeded -> {
                binding.statusText.text = event.question
                speakFeedback(event.question)
            }
            
            is VoiceMapperEvent.AudioFeedback -> {
                speakFeedback(event.message)
            }
        }
    }
    
    private fun speakFeedback(text: String) {
        if (ttsReady && viewModel.audioFeedbackEnabled.value) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "voice_mapper_feedback")
        }
    }
    
    private fun showEditDialog(edit: VoiceMapperEdit) {
        VoiceMapperEditDialogFragment.newInstance(edit).show(
            childFragmentManager,
            "edit_dialog"
        )
    }
    
    private fun showSettingsDialog() {
        VoiceMapperSettingsDialogFragment().show(
            childFragmentManager,
            "settings_dialog"
        )
    }
    
    private fun showHelpDialog() {
        val helpText = """
            Voice Mapping Commands:
            
            Adding POIs:
            • "McDonald's on the left"
            • "Gas station Shell on the right"
            • "On the left, KFC, Taco Bell, addresses 123, 125"
            
            With details:
            • "Bench about 20 meters back"
            • "Fire hydrant on the left, just passed it"
            
            Modifications:
            • "The bakery is now a restaurant"
            • "Remove the ATM, doesn't exist"
            
            Tips:
            • Speak clearly and at moderate pace
            • Include left/right for positioning
            • Long press mic for continuous mode
            • Tap pending edits to modify before confirming
        """.trimIndent()
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Voice Mapping Help")
            .setMessage(helpText)
            .setPositiveButton("Got it", null)
            .show()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        tts?.shutdown()
        _binding = null
    }
    
    companion object {
        fun newInstance() = VoiceMapperFragment()
    }
}
