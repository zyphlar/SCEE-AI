package de.westnordost.streetcomplete.voicemapper

import android.content.Context
import android.content.SharedPreferences
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.qualifier.named
import org.koin.dsl.module

/**
 * Koin dependency injection module for Voice Mapper feature
 * 
 * Add this module to your app's Koin modules in Application class:
 * 
 * ```kotlin
 * startKoin {
 *     modules(
 *         // ... other modules
 *         voiceMapperModule
 *     )
 * }
 * ```
 */
val voiceMapperModule = module {
    
    // AI Processor
    single {
        val prefs: SharedPreferences = get()
        val apiKey = prefs.getString("anthropic_api_key", "") ?: ""
        val endpoint = prefs.getString(
            VoiceMapperPrefs.KEY_API_ENDPOINT,
            "https://api.anthropic.com/v1/messages"
        ) ?: "https://api.anthropic.com/v1/messages"
        
        VoiceMapperAIProcessor(apiKey, endpoint)
    }
    
    // Voice Mapper Service
    single {
        VoiceMapperService(androidContext()).apply {
            initialize()
        }
    }
    
    // ViewModel
    viewModel {
        VoiceMapperViewModel(get())
    }
}

/**
 * Extension function to register voice mapper in the main activity
 */
fun Context.initializeVoiceMapper() {
    // Any additional initialization can go here
}
